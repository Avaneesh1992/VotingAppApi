import { Routes } from '@angular/router';
import { Voting } from './voting/voting';
import { Addcandidate } from './addcandidate/addcandidate';
import { Addvoter } from './addvoter/addvoter';

export const routes: Routes = [
{ path: '', component: Voting },
{ path: 'add-candidate', component: Addcandidate },
{ path: 'add-voter', component: Addvoter }
];
