import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Votingservice } from '../votingservice';
import { Voter } from '../models/voter.model';

@Component({
  selector: 'app-addvoter',
   standalone: true,
  imports: [CommonModule],
  templateUrl: './addvoter.html',
  styleUrl: './addvoter.css',
})
export class Addvoter {
  voterName = signal('');
  voters = signal<Voter[]>([]);
  constructor(private votingService: Votingservice) {
    this.loadData();
  }
  loadData(): void {
    this.votingService.getVoters().subscribe(res => {
      if (res.statusCode === 200) {
        this.voters.set(res.data);
      }
    });
  }
  onNameChange(event: Event) {
    this.voterName.set(
      (event.target as HTMLInputElement).value
    );
  }

  saveVoter() {
    debugger
    if (!this.voterName().trim()) return;
    debugger
    this.votingService.addVoter(this.voterName())
      .subscribe(() => {
        alert('Voter added successfully');
        this.voterName.set('');
        this.loadData();
      });
      
  }
}