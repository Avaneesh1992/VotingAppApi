import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Votingservice } from '../votingservice';
import { Candidate } from '../models/candidate.model';

@Component({
  selector: 'app-addcandidate',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './addcandidate.html',
  styleUrl: './addcandidate.css',
})
export class Addcandidate {
  candidateName = signal('');
 candidates = signal<Candidate[]>([]);

  constructor(private votingService: Votingservice) {
    this.loadData();
  }

  loadData() {
    this.votingService.getCandidates().subscribe(res => {
      if (res.statusCode === 200) {
        this.candidates.set(res.data);
      }
    });
  }

  onNameChange(event: Event) {
    this.candidateName.set(
      (event.target as HTMLInputElement).value
    );
  }

  saveCandidate() {
    if (!this.candidateName().trim()) return;

    this.votingService.addCandidate(this.candidateName())
      .subscribe(() => {
        alert('Candidate added successfully');
        this.candidateName.set('');
        this.loadData();
      });
    }

}
