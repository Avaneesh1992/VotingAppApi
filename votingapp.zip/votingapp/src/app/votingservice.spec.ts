import { TestBed } from '@angular/core/testing';

import { Votingservice } from './votingservice';

describe('Votingservice', () => {
  let service: Votingservice;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(Votingservice);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
