import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Votingservice } from '../votingservice';
import { Candidate } from '../models/candidate.model';
import { Voter } from '../models/voter.model';

@Component({
  selector: 'app-voting',
  imports: [CommonModule, FormsModule],
  templateUrl: './voting.html',
  styleUrl: './voting.css',
})
export class Voting {
  candidates = signal<Candidate[]>([]);
  voters = signal<Voter[]>([]);

  selectedCandidateId = signal<number | null>(null);
  selectedVoterId = signal<number | null>(null);

  constructor(private votingService: Votingservice) {
    this.loadData();
  }

  loadData(): void {
    this.votingService.getCandidates().subscribe(res => {
      if (res.statusCode === 200) {
        this.candidates.set(res.data);
      }
    });

    this.votingService.getVoters().subscribe(res => {
      if (res.statusCode === 200) {
        this.voters.set(res.data);
      }
    });
  }

  onCandidateChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.selectedCandidateId.set(Number(value));
  }

  onVoterChange(event: Event): void {
    const value = (event.target as HTMLSelectElement).value;
    this.selectedVoterId.set(Number(value));
  }

  castVote(): void {
    debugger
    if (!this.selectedCandidateId() || !this.selectedVoterId()) {
      alert('Please select candidate and voter');
      return;
    }
    debugger
    this.votingService
      .castVote(this.selectedCandidateId()!, this.selectedVoterId()!)
      .subscribe({
        next: (res) => {
          if (res.statusCode === 200) {
            alert('Vote cast successfully ✅');
            this.loadData(); // refresh candidates & voters
          }
        },
        error: (err) => {
          alert(err.error?.message || 'Error while casting vote');
        }
      });
  }
  refresh(): void {
    this.loadData();
  }
}