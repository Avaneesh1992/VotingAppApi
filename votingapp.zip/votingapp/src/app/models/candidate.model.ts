export interface Candidate {
  id: number;
  name: string;
  voteCount: number;
}
