import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ApiResult } from './models/api-result.model';
import { Candidate } from './models/candidate.model';
import { Voter } from './models/voter.model';

@Injectable({
  providedIn: 'root',
})
export class Votingservice {
  private readonly apiUrl = 'https://localhost:7001/api';
  constructor(private http: HttpClient) { }

  getCandidates(): Observable<ApiResult<Candidate[]>> {
    return this.http.get<ApiResult<Candidate[]>>(`${this.apiUrl}/candidates`);
  }

  getVoters(): Observable<ApiResult<Voter[]>> {
    return this.http.get<ApiResult<Voter[]>>(`${this.apiUrl}/voters`);
  }
  addCandidate(name: string) {
    return this.http.post(`${this.apiUrl}/candidates`, { name });
  }

  addVoter(name: string) {
    return this.http.post(`${this.apiUrl}/voters`, { name });
  }
  castVote(candidateId: number, voterId: number) {
    return this.http.post<ApiResult<null>>(`${this.apiUrl}/vote`, {
      candidateId,
      voterId
    });
  }
}
