# Copilot instructions — VotingApp

Quick summary
- Small Angular 21 application with optional SSR. Source root: `src/`.
- Client entry: [src/main.ts](src/main.ts). Server/SSR entry points: [src/main.server.ts](src/main.server.ts) and [src/server.ts](src/server.ts). Build/serve configured in [angular.json](angular.json).

How to run (developer flows)
- Dev server: `npm install` then `npm start` (runs `ng serve`).
- Production build: `npm run build` then `npm run serve:ssr:votingapp` to run the SSR server from `dist/`.
- Tests: `npm test` (Angular CLI test runner). Note: `vitest` is present in devDependencies but default `ng test` is used.

Key integration points
- Backend API expected at `https://localhost:7001/api`. See `src/app/votingservice.ts` for exact endpoints: `/candidates`, `/voters`, `/vote`.
- Models are under `src/app/models/` (see [candidate.model.ts](src/app/models/candidate.model.ts) and [voter.model.ts](src/app/models/voter.model.ts)). Responses wrap payloads in `ApiResult<T>` (`src/app/models/api-result.model.ts`).

Notable patterns and gotchas (be explicit)
- Components: many components are written as standalone-style (they use an `imports` array). Example: [src/app/voting/voting.ts](src/app/voting/voting.ts).
- Inconsistent import paths appear in the codebase:
  - `votingservice.ts` imports models as `models/...` (no leading `./`).
  - `voting.ts` contains `import { Voter } from '/models/voter.model';` (leading `/`) and `import { Candidate } from './models/candidate.model';` (relative). These inconsistent forms often cause TypeScript resolution issues — prefer relative imports (`./` or `../`) or confirm `paths` in `tsconfig.json`.
- Metadata typos: `Voting` component uses `styleUrl` (singular) instead of `styleUrls` (plural). If a component fails to apply styles or compile, check metadata keys in [src/app/voting/voting.ts](src/app/voting/voting.ts).
- SSR: `angular.json` contains `server` and `ssr` entries; the server bundle is produced under `dist/` and served by `node dist/.../server.mjs`. When modifying server-side code, rebuild (`npm run build`) before running the SSR server.

What to change or verify when editing code
- When adding or moving models/services, keep imports consistent with existing `src/app/models` layout.
- For API-related changes, update `Votingservice` (`src/app/votingservice.ts`) and adjust tests in `src/app/*.spec.ts` accordingly.
- When fixing build errors on components, first check for incorrect metadata keys (`templateUrl`, `styleUrls`, `imports`) and import path typos.

Files you will likely open first
- [src/app/votingservice.ts](src/app/votingservice.ts)
- [src/app/voting/voting.ts](src/app/voting/voting.ts)
- [src/app/models/api-result.model.ts](src/app/models/api-result.model.ts)
- [src/main.server.ts](src/main.server.ts) and [src/server.ts](src/server.ts)
- [angular.json](angular.json) and [package.json](package.json)

Quick examples
- Voting service base URL:
  - `private readonly apiUrl = 'https://localhost:7001/api'` (see [src/app/votingservice.ts](src/app/votingservice.ts)).
- Vote call:
  - POST to `${apiUrl}/vote` with `{ candidateId, voterId }`.

If something is unclear or missing
- Tell me which area you want expanded (tests, SSR, API mock guidance, or import/tsconfig rules) and I will update this file with concrete examples and commands.
